import { useMemo, useState } from "react";
import { ArrowRight, Search, Trash2 } from "lucide-react";
import { searchBids } from "../api";
import type { Bid, UiMessage } from "../types";
import { localIsoDate, toPncpDate } from "../utils";
import { DateRangePicker } from "./DateRangePicker";
import { StatusMessage } from "./StatusMessage";

interface SearchBlockProps {
  onUseLink: (link: string) => void;
}

function defaultDates() {
  const start = new Date();
  const end = new Date(start);
  end.setDate(end.getDate() + 29);
  return { start: localIsoDate(start), end: localIsoDate(end) };
}

export function SearchBlock({ onUseLink }: SearchBlockProps) {
  const defaults = useMemo(defaultDates, []);
  const [startDate, setStartDate] = useState(defaults.start);
  const [endDate, setEndDate] = useState(defaults.end);
  const [uf, setUf] = useState("");
  const [keyword, setKeyword] = useState("");
  const [objectType, setObjectType] = useState("");
  const [modality, setModality] = useState("6");
  const [results, setResults] = useState<Bid[]>([]);
  const [message, setMessage] = useState<UiMessage | null>(null);
  const [busy, setBusy] = useState(false);

  const clear = () => {
    setStartDate("");
    setEndDate("");
    setUf("");
    setKeyword("");
    setObjectType("");
    setModality("");
    setResults([]);
    setMessage({ kind: "info", text: "Filtros limpos." });
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if ((startDate && !endDate) || (!startDate && endDate)) {
      setMessage({ kind: "warning", text: "Selecione as datas inicial e final." });
      return;
    }
    if (startDate && endDate) {
      const start = new Date(`${startDate}T00:00:00`);
      const end = new Date(`${endDate}T00:00:00`);
      const days = Math.round((end.getTime() - start.getTime()) / 86_400_000) + 1;
      if (days < 1 || days > 30) {
        setMessage({ kind: "warning", text: "Selecione um período de até 30 dias." });
        return;
      }
    }
    if (startDate && endDate && endDate < startDate) {
      setMessage({ kind: "warning", text: "A data final deve ser posterior à data inicial." });
      return;
    }
    setBusy(true);
    setMessage({ kind: "info", text: "Consultando contratações no PNCP..." });
    try {
      const params = new URLSearchParams({
        dataInicial: toPncpDate(startDate),
        dataFinal: toPncpDate(endDate),
        uf: uf.trim().toUpperCase(),
        palavraChave: keyword.trim(),
        tipoObjeto: objectType,
        codigoModalidadeContratacao: modality,
        tamanhoPagina: "10",
      });
      const payload = await searchBids(params);
      setResults(payload.results || []);
      setMessage({
        kind: payload.results?.length ? "success" : "warning",
        text: payload.results?.length
          ? `${payload.results.length} contratação(ões) encontrada(s) em ${payload.pages_checked || 1} página(s) do PNCP.`
          : "Nenhuma contratação encontrada com estes filtros.",
      });
    } catch (error) {
      setMessage({
        kind: "error",
        text: error instanceof Error ? error.message : "Não foi possível consultar o PNCP.",
      });
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="workspace-section" aria-labelledby="search-heading">
      <div className="section-heading">
        <div>
          <span className="section-kicker">Bloco 1</span>
          <h2 id="search-heading">Consulta PNCP</h2>
          <p>Localize contratações abertas e use o link oficial na proposta.</p>
        </div>
      </div>

      <form className="search-form" onSubmit={submit}>
        <div className="period-field">
          <span className="field-label">Período</span>
          <DateRangePicker
            startDate={startDate}
            endDate={endDate}
            onChange={(start, end) => {
              setStartDate(start);
              setEndDate(end);
            }}
          />
          <small>Selecione um período de até 30 dias.</small>
        </div>
        <label>
          UF
          <input
            value={uf}
            maxLength={2}
            placeholder="SP"
            onChange={(e) => setUf(e.target.value.replace(/[^a-z]/gi, "").slice(0, 2))}
          />
        </label>
        <label>
          Palavra-chave
          <input
            value={keyword}
            maxLength={120}
            placeholder="Ex.: mobiliário"
            onChange={(e) => setKeyword(e.target.value)}
          />
        </label>
        <label>
          Tipo do objeto
          <select value={objectType} onChange={(e) => setObjectType(e.target.value)}>
            <option value="">Materiais e serviços</option>
            <option value="material">Materiais</option>
            <option value="servico">Serviços</option>
          </select>
        </label>
        <label>
          Modalidade
          <select value={modality} onChange={(e) => setModality(e.target.value)}>
            <option value="6">Pregão eletrônico</option>
            <option value="8">Dispensa eletrônica</option>
            <option value="">Todas</option>
          </select>
        </label>
        <div className="form-actions">
          <button className="button button-primary" type="submit" disabled={busy}>
            <Search size={17} />
            {busy ? "Consultando..." : "Buscar contratações"}
          </button>
          <button className="button button-secondary" type="button" disabled={busy} onClick={clear}>
            <Trash2 size={17} />
            Limpar
          </button>
        </div>
      </form>

      <StatusMessage message={message} />

      <div className="data-table-wrap search-results">
        {results.length ? (
          <table className="data-table">
            <thead>
              <tr>
                <th>Órgão</th>
                <th>Local</th>
                <th>Número</th>
                <th>Objeto</th>
                <th>Encerramento</th>
                <th aria-label="Ações" />
              </tr>
            </thead>
            <tbody>
              {results.map((bid) => (
                <tr key={`${bid.cnpj}-${bid.ano}-${bid.sequencial}`}>
                  <td>{bid.orgao}</td>
                  <td>{[bid.municipio, bid.uf].filter(Boolean).join(" / ")}</td>
                  <td>{bid.numeroCompra}</td>
                  <td className="description-cell">{bid.objeto}</td>
                  <td>{bid.encerramento ? new Date(bid.encerramento).toLocaleDateString("pt-BR") : ""}</td>
                  <td>
                    <button
                      className="button button-small button-secondary"
                      type="button"
                      onClick={() => onUseLink(bid.link)}
                    >
                      Usar
                      <ArrowRight size={15} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="empty-state">Use os filtros para consultar contratações abertas.</div>
        )}
      </div>
    </section>
  );
}
